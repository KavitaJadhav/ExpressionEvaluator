Expression Evaluator
==========


configuration 
-------------
  Your classPath must contain 'EXP_EVAL' variable
 
   
  