Expression Evaluator
==========


configuration 
-------------
Extract the "expression-evaluator.zip".
Set the environment variable with the name of 'EVALUATOR_HOME'.
Use shell file to run evaluator.

   
Release 1.0 
--------------

It will add two positive integer numbers ;
Space is mandatory between operator and operand;
Brackets are not allowed .

`Example - jk_ExpEval.sh "4 + 5" `

this will give ans : 9
