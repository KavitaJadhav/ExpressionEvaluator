Expression Evaluator
==========


configuration 
-------------
  Your classPath must contain 'EVALUATOR' variable
  
  

 
   
Release 1.0 
--------------

It will add two positive integer numbers ;

`Example - jk_ExpEval.sh "4 + 5" `

this will give ans : 9
